
-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `user_type` varchar(255) NOT NULL,
  `role` varchar(50) NOT NULL,
  `access_type` varchar(250) DEFAULT NULL COMMENT 'canteen, locker, theme_park',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) NOT NULL,
  `modified_on` datetime NOT NULL DEFAULT '0000-01-01 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `modified_by` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `name`, `user_name`, `password`, `user_type`, `role`, `access_type`, `status`, `created_on`, `created_by`, `modified_on`, `modified_by`) VALUES
(1, 'Ramachandiran', 'ram', '5e8edd851d2fdfbd7415232c67367cc3', 'root_admin', 'developer', 'canteen', 1, '2019-07-04 06:41:57', 1, '2019-10-31 15:38:18', NULL),
(2, 'Ragunathan', 'admin', '21232f297a57a5a743894a0e4a801fc3', 'super_admin', 'admin', 'canteen', 1, '2019-07-04 11:48:44', 1, '2019-10-31 15:38:18', NULL),
(3, 'Store Manager1', 'store_manager1', '1d0258c2440a8d19e716292b231e3190', 'store', 'manager', 'canteen', 1, '2019-07-05 09:45:29', 1, '2019-10-31 15:38:18', NULL),
(4, 'Store Manager2', 'store_manager2', '1d0258c2440a8d19e716292b231e3190', 'store', 'manager', 'canteen', 1, '2019-07-04 06:41:57', 1, '2019-10-31 15:38:18', NULL),
(5, 'Stall Operator1', 'stall_operator1', '4b583376b2767b923c3e1da60d10de59', 'stall', 'operator', 'canteen', 1, '2019-07-11 11:53:11', 1, '2019-10-31 15:38:18', NULL),
(6, 'Stall Operator2', 'stall_operator2', '4b583376b2767b923c3e1da60d10de59', 'stall', 'operator', 'canteen', 1, '2019-07-11 12:19:59', 1, '2019-10-31 15:38:18', NULL),
(7, 'Manikandan', 'mani', '5e8edd851d2fdfbd7415232c67367cc3', 'root_admin', 'developer', 'canteen', 1, '2019-07-04 06:41:57', 1, '2019-10-31 15:38:18', NULL),
(8, 'Suresh', 'suresh', '5e8edd851d2fdfbd7415232c67367cc3', 'root_admin', 'developer', 'canteen', 1, '2019-07-04 06:41:57', 1, '2019-10-31 15:38:18', NULL),
(9, 'Ragunathan', 'ragu', '5e8edd851d2fdfbd7415232c67367cc3', 'root_admin', 'developer', 'canteen', 1, '2019-07-04 06:41:57', 1, '2019-10-31 15:38:18', NULL),
(10, 'Chandru', 'locker_operator1', '4b583376b2767b923c3e1da60d10de59', 'stall', 'operator', 'locker', 1, '2019-10-31 11:44:17', 1, '2019-11-01 11:37:48', NULL),
(11, 'Dharanishwar', 'park_operator1', '4b583376b2767b923c3e1da60d10de59', 'stall', 'operator', 'canteen,locker,theme_park', 1, '2019-10-31 11:45:37', 1, '2019-11-01 12:38:21', NULL);
