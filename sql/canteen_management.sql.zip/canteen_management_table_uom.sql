
-- --------------------------------------------------------

--
-- Table structure for table `uom`
--

CREATE TABLE `uom` (
  `uom_id` int(11) NOT NULL,
  `uom` varchar(10) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `uom`
--

INSERT INTO `uom` (`uom_id`, `uom`, `description`, `status`) VALUES
(1, 'KG', 'Kilogram', 1),
(2, 'L', 'Litter', 1),
(5, 'NOs', 'Numbers', 1);
