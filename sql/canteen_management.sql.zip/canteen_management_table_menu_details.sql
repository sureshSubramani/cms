
-- --------------------------------------------------------

--
-- Table structure for table `menu_details`
--

CREATE TABLE `menu_details` (
  `menu_id` int(11) NOT NULL,
  `order_no` int(11) NOT NULL,
  `menu_type` int(11) NOT NULL,
  `menu_icon` varchar(50) DEFAULT NULL,
  `menu_name` varchar(255) NOT NULL,
  `menu_url` varchar(255) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL,
  `modified_on` datetime NOT NULL DEFAULT '0000-01-01 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `modified_by` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menu_details`
--

INSERT INTO `menu_details` (`menu_id`, `order_no`, `menu_type`, `menu_icon`, `menu_name`, `menu_url`, `parent_id`, `status`, `created_on`, `created_by`, `modified_on`, `modified_by`) VALUES
(1, 1, 0, 'fa fa-dashboard', 'Dashboard', 'index', 0, 1, '2019-07-12 22:42:25', 1, '2019-10-01 11:10:26', 1),
(2, 12, 0, 'fa fa-cog', 'Test Main Menu', '', 0, 1, '2019-07-13 01:18:31', 1, '2019-10-01 17:28:43', 1),
(34, 3, 1, NULL, 'Sales Reports', 'sales_reports', 31, 1, '2019-09-30 09:33:46', 1, '2019-10-01 10:03:29', NULL),
(6, 10, 0, 'fa fa-user', 'Users', '', 0, 1, '2019-07-13 01:52:56', 1, '2019-10-01 17:20:38', 1),
(7, 5, 0, 'fa fa-database', 'Products', '', 0, 1, '2019-07-13 01:53:27', 1, '2019-10-01 17:23:29', 1),
(8, 2, 0, 'fa fa-building', 'Store', 'store_details', 0, 1, '2019-07-13 01:53:39', 1, '2019-10-01 17:22:57', 1),
(9, 11, 0, 'fa fa-bars', 'Menus', '', 0, 1, '2019-07-13 01:53:53', 1, '2019-10-01 17:26:45', 1),
(10, 1, 1, '', 'User Details', 'user_details', 6, 1, '2019-07-13 02:17:30', 1, '2019-10-01 16:58:23', 1),
(11, 2, 1, NULL, 'Menu Details', 'menu_details', 9, 1, '2019-07-13 03:26:49', 1, '2019-10-01 17:26:45', 1),
(12, 2, 1, NULL, 'User Role', 'user_role', 6, 1, '2019-07-13 03:26:49', 1, '2019-10-01 16:58:23', NULL),
(33, 2, 1, NULL, 'Payment Reports', 'payment_reports', 31, 1, '2019-09-30 09:33:23', 1, '2019-10-01 10:03:29', NULL),
(32, 1, 1, NULL, 'Purchase Reports', 'purchase_reports', 31, 1, '2019-09-30 09:33:01', 1, '2019-10-01 10:03:29', NULL),
(31, 9, 0, 'fa fa-bar-chart', 'Reports', '', 0, 1, '2019-09-30 09:27:24', 1, '2019-10-01 17:21:03', 1),
(30, 1, 1, '', 'Sales Details', 'sales', 28, 1, '2019-09-30 09:26:43', 1, '2019-10-29 16:13:03', 8),
(27, 2, 1, NULL, 'Invoice / Payment', 'invoice_payment', 24, 1, '2019-09-30 09:15:47', 1, '2019-10-04 12:25:26', 1),
(28, 8, 0, 'fa fa-money', 'Sales', '', 0, 1, '2019-09-30 09:18:19', 1, '2019-10-01 17:21:43', 1),
(29, 2, 1, '', 'Stock of Sales', 'stock_sales', 28, 1, '2019-09-30 09:25:50', 1, '2019-10-29 16:16:09', 8),
(22, 3, 0, 'fa fa-home', 'Stall', 'stall_details', 0, 1, '2019-07-15 23:15:49', 1, '2019-10-01 17:23:06', 1),
(23, 4, 0, 'fa fa-users', 'Supplier', 'supplier_details', 0, 1, '2019-09-09 03:45:43', 1, '2019-10-01 17:23:18', 1),
(24, 6, 0, 'fa fa-suitcase', 'Purchase', '', 0, 1, '2019-09-09 03:46:07', 1, '2019-10-01 17:23:58', 1),
(26, 2, 1, NULL, 'Menu Preference', 'menu_preference', 9, 1, '2019-09-13 07:14:02', 1, '2019-10-01 17:26:45', NULL),
(35, 1, 1, NULL, 'Purchase Details', 'purchase', 24, 1, '2019-09-30 09:39:33', 1, '2019-10-03 12:21:39', NULL),
(36, 5, 1, NULL, 'Stock of Store', 'stock_of_store', 24, 1, '2019-09-30 09:41:19', 1, '2019-10-04 11:50:10', NULL),
(37, 3, 1, NULL, 'Movement Tracker', 'movement_tracker', 24, 1, '2019-09-30 09:41:50', 1, '2019-10-01 10:03:29', NULL),
(38, 6, 1, NULL, 'Stock of Stall', 'stock_of_stall', 24, 1, '2019-09-30 09:42:11', 1, '2019-10-04 11:50:12', 1),
(39, 2, 1, '', 'Product Category', 'product_category', 7, 1, '2019-09-30 09:49:09', 1, '2019-10-01 13:27:00', 1),
(40, 1, 1, '', 'Product Details', 'product_details', 7, 1, '2019-09-30 09:49:34', 1, '2019-10-01 13:26:50', 1),
(41, 3, 1, NULL, 'Sales Products', 'sales_products', 7, 1, '2019-09-30 09:50:05', 1, '2019-10-01 10:03:29', NULL),
(42, 4, 1, NULL, 'Ingredients', 'ingredients', 7, 0, '2019-09-30 09:50:29', 1, '2019-10-04 11:58:11', NULL),
(43, 4, 1, NULL, 'Wastage Product', 'wastage', 24, 1, '2019-09-30 09:42:11', 1, '2019-10-04 11:48:55', NULL),
(50, 2, 1, '', 'Payment by Supplier', 'payment_by_supplier', 24, 1, '2019-10-08 06:40:46', 1, '2019-10-08 12:11:10', 1),
(44, 1, 1, '', 'Test Sub Menu1', '', 2, 1, '2019-10-01 11:59:10', 1, '0000-01-01 00:00:00', NULL),
(45, 2, 1, '', 'Test Sub Menu2', '', 2, 1, '2019-10-01 11:59:46', 1, '0000-01-01 00:00:00', NULL),
(46, 1, 2, '', 'Test Inner Sub1 Menu1', 'tesr', 44, 1, '2019-10-01 12:00:20', 1, '2019-10-10 09:04:43', 7),
(47, 2, 2, '', 'Test Inner Sub1 Menu2', '', 44, 1, '2019-10-01 12:00:30', 1, '2019-10-08 10:03:37', 1),
(48, 1, 2, '', 'Test Inner Sub2 Menu1', 'index', 45, 1, '2019-10-01 12:03:26', 1, '2019-10-09 11:14:22', 7),
(49, 2, 2, '', 'Test Inner Sub2 Menu2', 'index', 45, 1, '2019-10-01 12:03:38', 1, '2019-10-09 17:44:56', 7),
(51, 4, 1, '', 'Sales Products for Stall', 'stall_products', 7, 1, '2019-10-09 06:17:02', 7, '2019-10-10 10:50:00', 1),
(52, 11, 0, 'fa fa-lock', 'Locker', 'locker', 0, 1, '2019-11-01 05:14:57', 1, '0000-01-01 00:00:00', NULL),
(53, 11, 0, 'fa fa-ticket', 'Theme Park', 'ticket_entry', 0, 1, '2019-11-01 05:15:46', 1, '0000-01-01 00:00:00', NULL);
