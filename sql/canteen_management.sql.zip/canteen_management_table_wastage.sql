
-- --------------------------------------------------------

--
-- Table structure for table `wastage`
--

CREATE TABLE `wastage` (
  `wastage_id` int(11) NOT NULL,
  `store_code` varchar(25) NOT NULL,
  `stall_code` varchar(25) NOT NULL,
  `product_code` varchar(50) NOT NULL,
  `quantity_of_waste` double NOT NULL,
  `uom` varchar(10) NOT NULL,
  `approve_status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0=Pending, 1=Accepted, 2=Rejected',
  `approved_by` int(11) DEFAULT NULL COMMENT 'Approved user ID',
  `description` varchar(250) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) NOT NULL COMMENT 'Wastage entered user ID',
  `modified_on` datetime NOT NULL DEFAULT '0000-01-01 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `modified_by` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wastage`
--

INSERT INTO `wastage` (`wastage_id`, `store_code`, `stall_code`, `product_code`, `quantity_of_waste`, `uom`, `approve_status`, `approved_by`, `description`, `status`, `created_on`, `created_by`, `modified_on`, `modified_by`) VALUES
(1, 'STR003', 'STR003STL003', 'RICE02', 2, 'KG', 0, NULL, NULL, 1, '2019-10-16 11:33:55', 5, '2019-10-23 10:49:20', 5),
(2, 'STR003', 'STR003STL002', 'RICE02', 1.5, 'KG', 0, NULL, NULL, 1, '2019-10-18 11:10:44', 5, '2019-10-23 10:52:18', 3),
(3, 'STR001', 'STR001STL001', 'CORN01', 4, 'NOs', 0, NULL, NULL, 1, '2019-10-16 06:41:52', 5, '2019-10-23 18:05:50', 3),
(4, 'STR001', 'STR001STL001', 'LAYS01', 2, 'NOs', 0, 3, NULL, 1, '2019-10-16 04:40:37', 5, '2019-10-23 18:05:50', 5),
(5, 'STR001', 'STR001STL001', 'VEG005', 2, 'NOs', 0, 3, NULL, 1, '2019-10-16 06:41:52', 5, '2019-10-23 18:05:50', 5),
(6, 'STR001', 'STR001STL001', 'SUGAR001', 7, 'NOs', 0, 3, NULL, 1, '2019-10-16 04:40:09', 5, '2019-10-23 18:05:50', 5),
(7, 'STR003', 'STR003STL003', 'RICE01', 2, 'KG', 0, NULL, NULL, 1, '2019-10-16 11:31:52', 5, '2019-10-23 10:52:11', 5),
(8, 'STR001', 'STR001STL001', 'LAYS01', 4, 'NOs', 0, NULL, NULL, 1, '2019-10-15 11:27:58', 5, '2019-10-23 18:05:50', 3),
(9, 'STR001', 'STR001STL001', 'RICE01', 6, 'KG', 0, NULL, NULL, 1, '2019-10-15 11:19:06', 5, '2019-10-23 10:52:04', 5),
(10, 'STR001', 'STR001STL001', 'CORN01', 4, 'KG', 0, NULL, NULL, 1, '2019-10-15 11:19:06', 5, '2019-10-23 10:51:46', 3),
(11, 'STR003', 'STR003STL002', 'CORN01', 1, 'NOs', 0, NULL, NULL, 1, '2019-10-18 11:10:44', 5, '2019-10-23 18:05:50', 3),
(12, 'STR001', 'STR001STL001', 'CORN01', 10, 'KG', 0, NULL, NULL, 1, '2019-10-19 12:09:16', 5, '2019-10-23 10:52:25', 3),
(13, 'STR003', 'STR003STL002', 'LAYS02', 1, 'NOs', 0, NULL, NULL, 1, '2019-10-24 05:08:26', 5, '0000-01-01 00:00:00', NULL);
