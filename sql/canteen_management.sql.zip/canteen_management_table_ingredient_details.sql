
-- --------------------------------------------------------

--
-- Table structure for table `ingredient_details`
--

CREATE TABLE `ingredient_details` (
  `ingredients_id` int(11) NOT NULL,
  `sales_product_id` int(11) NOT NULL,
  `product_code` varchar(25) NOT NULL,
  `quantity` double NOT NULL COMMENT 'Required quantity',
  `uom` varchar(11) NOT NULL COMMENT 'Unit of Measurement',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) NOT NULL,
  `modified_on` datetime NOT NULL DEFAULT '0000-01-01 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `modified_by` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ingredient_details`
--

INSERT INTO `ingredient_details` (`ingredients_id`, `sales_product_id`, `product_code`, `quantity`, `uom`, `status`, `created_on`, `created_by`, `modified_on`, `modified_by`) VALUES
(33, 3, 'VEG0040', 0.1, 'KG', 1, '2019-10-24 11:48:01', 1, '0000-01-01 00:00:00', NULL),
(32, 2, 'VEG0043', 0.05, 'KG', 1, '2019-10-24 11:47:52', 1, '0000-01-01 00:00:00', NULL),
(31, 2, 'RICE01', 0.2, 'KG', 1, '2019-10-24 11:47:52', 1, '0000-01-01 00:00:00', NULL),
(30, 2, 'VEG0029', 0.1, 'KG', 1, '2019-10-24 11:47:52', 1, '0000-01-01 00:00:00', NULL),
(29, 2, 'HERB0007', 0.02, 'KG', 1, '2019-10-24 11:47:52', 1, '0000-01-01 00:00:00', NULL),
(54, 5, 'VEG0029', 0.038, 'KG', 1, '2019-10-24 12:02:39', 1, '0000-01-01 00:00:00', NULL),
(26, 1, 'FLDR0001', 1, 'L', 1, '2019-10-24 11:47:18', 1, '0000-01-01 00:00:00', NULL),
(28, 2, 'ODEN0004', 0.1, 'L', 1, '2019-10-24 11:47:52', 1, '0000-01-01 00:00:00', NULL),
(35, 4, 'VEG0043', 0.05, 'KG', 1, '2019-10-24 11:48:04', 1, '0000-01-01 00:00:00', NULL),
(34, 4, 'RICE01', 0.2, 'KG', 1, '2019-10-24 11:48:04', 1, '0000-01-01 00:00:00', NULL),
(53, 5, 'VEG0026', 0.3, 'KG', 1, '2019-10-24 12:02:39', 1, '0000-01-01 00:00:00', NULL),
(52, 5, 'HERB0007', 0.03, 'KG', 1, '2019-10-24 12:02:39', 1, '0000-01-01 00:00:00', NULL),
(51, 5, 'HERB0005', 0.05, 'KG', 1, '2019-10-24 12:02:39', 1, '0000-01-01 00:00:00', NULL),
(50, 5, 'ODEN0007', 0.05, 'L', 1, '2019-10-24 12:02:39', 1, '0000-01-01 00:00:00', NULL),
(49, 5, 'HERB0004', 0.05, 'KG', 1, '2019-10-24 12:02:39', 1, '0000-01-01 00:00:00', NULL),
(48, 5, 'ODEN0004', 0.45, 'L', 1, '2019-10-24 12:02:39', 1, '0000-01-01 00:00:00', NULL),
(47, 5, 'HERB0001', 0.03, 'KG', 1, '2019-10-24 12:02:39', 1, '0000-01-01 00:00:00', NULL),
(46, 5, 'RCGR0001', 0.35, 'KG', 1, '2019-10-24 12:02:39', 1, '0000-01-01 00:00:00', NULL),
(55, 5, 'VEG0043', 0.1, 'KG', 1, '2019-10-24 12:02:39', 1, '0000-01-01 00:00:00', NULL),
(75, 6, 'VEG0043', 0.05, 'KG', 1, '2019-10-29 07:51:34', 8, '0000-01-01 00:00:00', NULL),
(74, 6, 'NSDF0009', 0.05, 'KG', 1, '2019-10-29 07:51:34', 8, '0000-01-01 00:00:00', NULL);
