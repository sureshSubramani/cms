
-- --------------------------------------------------------

--
-- Table structure for table `stall_details`
--

CREATE TABLE `stall_details` (
  `stall_id` int(11) NOT NULL,
  `store_code` varchar(50) NOT NULL,
  `stall_code` varchar(50) NOT NULL,
  `stall_name` varchar(100) NOT NULL,
  `stall_phone` varchar(50) NOT NULL COMMENT 'One or more phone / mobile numbers ',
  `status` tinyint(4) DEFAULT '1',
  `created_on` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) NOT NULL,
  `modified_on` datetime NOT NULL DEFAULT '0000-01-01 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `modified_by` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stall_details`
--

INSERT INTO `stall_details` (`stall_id`, `store_code`, `stall_code`, `stall_name`, `stall_phone`, `status`, `created_on`, `created_by`, `modified_on`, `modified_by`) VALUES
(39, 'STR001', 'STR001STL003', 'Stall A3', '88888888888', 1, '2019-10-19 02:08:08', 7, '2019-10-19 16:40:38', 1),
(36, 'STR003', 'STR003STL002', 'Stall C2', '88888888888', 1, '2019-10-17 01:49:09', 1, '2019-10-21 15:46:06', 1),
(35, 'STR003', 'STR003STL003', 'Stall C3', '9999999999', 1, '2019-10-10 06:06:02', 3, '2019-10-19 16:41:12', 1),
(34, 'STR002', 'STR002STL002', 'Stall B2', '9999999999', 1, '2019-10-10 06:05:11', 3, '2019-10-19 16:40:56', 1),
(33, 'STR001', 'STR001STL001', 'Stall A1', '9999999999', 1, '2019-10-10 06:03:29', 3, '2019-10-23 17:08:45', 3),
(38, 'STR001', 'STR001STL002', 'Stall A2', '88888888888', 1, '2019-10-19 02:08:00', 7, '2019-10-21 12:30:24', 3),
(37, 'STR004', 'STR004STL001', 'Stall D1', '9999999999', 1, '2019-10-17 22:59:38', 1, '2019-10-19 16:41:20', 1),
(40, 'STR001', 'STR001STL004', 'Stall A4', '88888888888', 1, '2019-10-19 03:53:31', 7, '2019-10-21 12:48:50', 3);
