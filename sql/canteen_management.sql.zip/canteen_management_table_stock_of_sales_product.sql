
-- --------------------------------------------------------

--
-- Table structure for table `stock_of_sales_product`
--

CREATE TABLE `stock_of_sales_product` (
  `sales_stock_id` int(11) NOT NULL,
  `store_code` varchar(25) NOT NULL,
  `stall_code` varchar(25) NOT NULL,
  `sales_product_id` int(11) NOT NULL,
  `quantity` double NOT NULL DEFAULT '0' COMMENT 'Available Quantity',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) NOT NULL,
  `modified_on` datetime NOT NULL DEFAULT '0000-01-01 00:00:00' ON UPDATE CURRENT_TIMESTAMP COMMENT 'Last modified on',
  `modified_by` int(11) DEFAULT NULL COMMENT 'Last modified by'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stock_of_sales_product`
--

INSERT INTO `stock_of_sales_product` (`sales_stock_id`, `store_code`, `stall_code`, `sales_product_id`, `quantity`, `status`, `created_on`, `created_by`, `modified_on`, `modified_by`) VALUES
(1, 'STR003', 'STR003STL002', 2, 20, 1, '2019-10-23 10:38:27', 3, '2019-10-29 12:17:44', NULL),
(2, 'STR003', 'STR003STL003', 11, 0, 1, '2019-10-23 10:38:44', 3, '2019-10-24 09:49:01', NULL),
(23, 'STR001', 'STR001STL001', 3, 200, 1, '2019-10-29 05:28:11', 3, '2019-10-29 10:58:23', NULL),
(24, 'STR001', 'STR001STL001', 4, 385, 1, '2019-10-29 05:28:11', 3, '2019-10-29 10:58:23', NULL),
(25, 'STR001', 'STR001STL001', 5, -6, 1, '2019-10-29 05:28:11', 3, '2019-10-31 10:30:01', 5),
(21, 'STR001', 'STR001STL001', 1, 50, 1, '2019-10-29 05:28:11', 3, '2019-10-29 10:58:23', NULL),
(22, 'STR001', 'STR001STL001', 2, 385, 1, '2019-10-29 05:28:11', 3, '2019-10-29 10:58:23', NULL),
(26, 'STR001', 'STR001STL001', 6, 0, 1, '2019-10-29 05:28:11', 3, '2019-10-29 13:22:17', NULL);
