
-- --------------------------------------------------------

--
-- Table structure for table `supplier_details`
--

CREATE TABLE `supplier_details` (
  `supplier_id` int(11) NOT NULL,
  `supplier_name` varchar(255) NOT NULL,
  `supplier_mobile` varchar(20) NOT NULL,
  `supplier_address` text NOT NULL,
  `supplier_city` varchar(55) NOT NULL,
  `supplier_gst` varchar(55) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` varchar(55) NOT NULL,
  `modified_on` datetime NOT NULL DEFAULT '0000-01-01 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `modified_by` varchar(55) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `supplier_details`
--

INSERT INTO `supplier_details` (`supplier_id`, `supplier_name`, `supplier_mobile`, `supplier_address`, `supplier_city`, `supplier_gst`, `status`, `created_on`, `created_by`, `modified_on`, `modified_by`) VALUES
(1, 'KANNAN DEPARTMENt', '9798589500', 'Mallasamuthram A', 'Salem', '68449899', 1, '2019-10-04 06:03:22', '', '2019-10-19 15:59:15', '7'),
(2, 'SURESH SUBRAMANI', '8884074278', 'sureshsubramani1986@gmail.com', 'Salem', '1290490', 1, '2019-10-04 06:03:30', '', '2019-10-19 15:21:10', '8'),
(3, 'Moorthy', '8989898900', 'Erode', 'Coimbatore', '2019010', 1, '2019-10-04 06:03:33', '', '0000-01-01 00:00:00', '8'),
(4, 'RAMS', '8884074278', 'Erode', 'Salem', '2019014', 1, '2019-10-04 06:03:36', '8', '2019-10-21 12:53:41', '8'),
(5, 'Ramesh', '8884074278', 'Idappadi', 'Avinashi', '201901256', 1, '2019-10-04 06:03:39', '8', '0000-01-01 00:00:00', '8'),
(6, 'Mohan', '8884074278', 'Erode', 'Erode', '20190150', 1, '2019-10-04 06:03:43', '8', '0000-01-01 00:00:00', '8'),
(7, 'Arumugam', '77847484749', 'Bavani', 'Coimbatore East', '2894048', 1, '2019-10-04 11:16:35', '8', '2019-10-19 15:21:41', '8'),
(10, 'KANNAN DEPARTMENT	', '8526964132', 'Athani', 'Erode', '33333', 1, '2019-10-19 09:52:49', '7', '0000-01-01 00:00:00', ''),
(11, 'KANNAN DEPARTMENff', '8526964132', 'Athani', 'Erode', 'fff', 1, '2019-10-19 10:26:03', '7', '0000-01-01 00:00:00', '');
