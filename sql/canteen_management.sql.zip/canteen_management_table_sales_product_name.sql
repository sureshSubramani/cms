
-- --------------------------------------------------------

--
-- Table structure for table `sales_product_name`
--

CREATE TABLE `sales_product_name` (
  `sales_product_id` int(11) NOT NULL,
  `sales_product_name` varchar(100) NOT NULL,
  `sales_product_type` varchar(100) DEFAULT NULL,
  `min_quantity` int(11) NOT NULL DEFAULT '0',
  `image` varchar(50) NOT NULL DEFAULT 's_product.jpg',
  `price` int(11) NOT NULL COMMENT 'Price per unit',
  `currency` varchar(10) NOT NULL DEFAULT 'INR',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) NOT NULL,
  `modified_on` datetime NOT NULL DEFAULT '0000-01-01 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `modified_by` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sales_product_name`
--

INSERT INTO `sales_product_name` (`sales_product_id`, `sales_product_name`, `sales_product_type`, `min_quantity`, `image`, `price`, `currency`, `status`, `created_on`, `created_by`, `modified_on`, `modified_by`) VALUES
(1, '1L Water Bottle', 'Mineral', 10, '5db17ceb1cfdb.jpg', 25, 'INR', 1, '2019-10-24 10:23:28', 1, '2019-10-24 17:17:18', NULL),
(2, 'Veg Fried Rice', 'Briyani', 10, '5db17e7326680.jpg', 100, 'INR', 1, '2019-10-24 10:35:31', 1, '2019-10-24 17:17:52', NULL),
(3, 'Pop Corn', 'Corn', 10, '5db17eeadafa2.jpg', 50, 'INR', 1, '2019-10-24 10:37:30', 1, '2019-10-24 17:18:01', NULL),
(4, 'Egg Fried Rice', 'Fried Rice', 10, '5db1854b52f2b.jpg', 55, 'INR', 1, '2019-10-24 11:04:43', 1, '2019-10-24 17:18:04', NULL),
(5, 'Mushroom Briyani', 'Chettinad', 10, '5db18a07516b5.jpg', 110, 'INR', 1, '2019-10-24 11:24:55', 1, '2019-10-24 17:20:18', NULL),
(6, 'Potato Flavour', 'Lays', 10, '5db7cdc07ff91.jpg', 10, 'INR', 1, '2019-10-29 05:27:28', 8, '0000-01-01 00:00:00', NULL);
