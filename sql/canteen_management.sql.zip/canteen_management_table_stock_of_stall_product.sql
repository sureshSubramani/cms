
-- --------------------------------------------------------

--
-- Table structure for table `stock_of_stall_product`
--

CREATE TABLE `stock_of_stall_product` (
  `stall_stock_id` int(11) NOT NULL,
  `store_code` varchar(25) NOT NULL,
  `stall_code` varchar(25) NOT NULL,
  `product_code` varchar(25) NOT NULL,
  `quantity` double NOT NULL COMMENT 'Available Stock',
  `uom` varchar(10) NOT NULL COMMENT 'Unit of Measurement',
  `conversed_quantity` double NOT NULL DEFAULT '0' COMMENT 'Multiple of this quantity with conversion value from Products',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) NOT NULL COMMENT 'Purchased by',
  `modified_on` datetime NOT NULL DEFAULT '0000-01-01 00:00:00' ON UPDATE CURRENT_TIMESTAMP COMMENT 'Last modified on',
  `modified_by` int(11) DEFAULT NULL COMMENT 'Last modified by'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stock_of_stall_product`
--

INSERT INTO `stock_of_stall_product` (`stall_stock_id`, `store_code`, `stall_code`, `product_code`, `quantity`, `uom`, `conversed_quantity`, `status`, `created_on`, `created_by`, `modified_on`, `modified_by`) VALUES
(6, 'STR001', 'STR001STL001', 'VEG005', 18, 'NOs', 0, 1, '2019-10-14 09:51:52', 3, '2019-10-23 18:05:20', 3),
(4, 'STR001', 'STR001STL001', 'RICE01', 77, 'KG', 0, 1, '2019-10-11 04:36:40', 3, '2019-10-23 16:18:12', 3),
(20, 'STR001', 'STR001STL001', 'VEG0040', 20, 'NOs', 0, 1, '2019-10-18 10:35:02', 3, '2019-10-23 18:05:20', 3),
(11, 'STR001', 'STR001STL001', 'SUGAR001', 26, 'NOs', 0, 1, '2019-10-15 12:33:47', 4, '2019-10-23 18:05:20', 3),
(14, 'STR001', 'STR001STL001', 'LAYS01', 1, 'NOs', 0, 1, '2019-10-15 12:44:55', 4, '2019-10-23 18:05:20', 3),
(19, 'STR003', 'STR003STL003', 'RICE02', 23, 'KG', 0, 1, '2019-10-16 10:47:40', 3, '2019-10-19 17:04:45', 3),
(18, 'STR003', 'STR003STL003', 'CORN01', 15, 'NOs', 0, 1, '2019-10-16 10:47:40', 3, '2019-10-23 18:05:20', 3),
(23, 'STR003', 'STR003STL002', 'SUGAR001', 10, 'NOs', 0, 1, '2019-10-23 09:03:37', 3, '2019-10-23 18:05:20', NULL),
(24, 'STR003', 'STR003STL002', 'LAYS02', 5, 'NOs', 0, 1, '2019-10-23 09:03:37', 3, '2019-10-23 18:05:20', NULL),
(25, 'STR003', 'STR003STL002', 'HERB0004', 2, 'KG', 0, 1, '2019-10-23 10:06:02', 3, '0000-01-01 00:00:00', NULL),
(26, 'STR003', 'STR003STL002', 'ODEN0004', 2, 'L', 0, 1, '2019-10-23 10:06:02', 3, '0000-01-01 00:00:00', NULL),
(27, 'STR003', 'STR003STL002', 'ODEN0007', 2, 'L', 0, 1, '2019-10-23 10:06:02', 3, '0000-01-01 00:00:00', NULL),
(28, 'STR003', 'STR003STL002', 'HERB0001', 2, 'KG', 0, 1, '2019-10-23 10:06:02', 3, '0000-01-01 00:00:00', NULL),
(29, 'STR003', 'STR003STL002', 'HERB0007', 2, 'KG', 0, 1, '2019-10-23 10:06:02', 3, '0000-01-01 00:00:00', NULL),
(30, 'STR003', 'STR003STL002', 'VEG0043', 5, 'KG', 0, 1, '2019-10-23 10:06:02', 3, '0000-01-01 00:00:00', NULL),
(31, 'STR003', 'STR003STL002', 'VEG0029', 5, 'KG', 0, 1, '2019-10-23 10:06:02', 3, '0000-01-01 00:00:00', NULL),
(32, 'STR003', 'STR003STL002', 'RCGR0001', 10, 'KG', 0, 1, '2019-10-23 10:06:02', 3, '0000-01-01 00:00:00', NULL),
(33, 'STR003', 'STR003STL002', 'VEG0026', 10, 'KG', 0, 1, '2019-10-23 10:06:02', 3, '0000-01-01 00:00:00', NULL),
(34, 'STR003', 'STR003STL002', 'HERB0005', 2, 'KG', 0, 1, '2019-10-23 10:10:05', 3, '0000-01-01 00:00:00', NULL),
(35, 'STR003', 'STR003STL003', 'HERB0005', 2, 'KG', 0, 1, '2019-10-23 10:10:33', 3, '0000-01-01 00:00:00', NULL),
(37, 'STR001', 'STR001STL001', 'FLDR0001', 50, 'L', 0, 1, '2019-10-29 04:41:53', 3, '0000-01-01 00:00:00', NULL),
(36, 'STR001', 'STR001STL001', 'VEG001', 20, 'KG', 0, 1, '2019-10-23 10:49:03', 3, '2019-10-23 16:19:04', 3);
