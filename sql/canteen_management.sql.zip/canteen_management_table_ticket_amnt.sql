
-- --------------------------------------------------------

--
-- Table structure for table `ticket_amnt`
--

CREATE TABLE `ticket_amnt` (
  `ticket_amnt_id` int(11) NOT NULL,
  `type` varchar(55) NOT NULL,
  `audult` float NOT NULL,
  `child` float NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) NOT NULL,
  `modified_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ticket_amnt`
--

INSERT INTO `ticket_amnt` (`ticket_amnt_id`, `type`, `audult`, `child`, `status`, `created_on`, `created_by`, `modified_on`) VALUES
(1, 'themepark', 600, 500, 1, '2019-09-25 11:24:57', 1, '2019-10-01 05:04:01'),
(2, 'locker', 80, 120, 1, '2019-09-25 11:24:57', 1, '2019-10-01 05:04:01');
