
-- --------------------------------------------------------

--
-- Table structure for table `store_details`
--

CREATE TABLE `store_details` (
  `store_id` int(11) NOT NULL,
  `store_name` varchar(100) NOT NULL,
  `store_code` varchar(50) NOT NULL,
  `store_loc` varchar(100) NOT NULL,
  `store_phone` varchar(50) NOT NULL COMMENT 'One or more phone / mobile numbers',
  `store_email` varchar(255) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) NOT NULL,
  `modified_on` datetime NOT NULL DEFAULT '0000-01-01 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `modified_by` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `store_details`
--

INSERT INTO `store_details` (`store_id`, `store_name`, `store_code`, `store_loc`, `store_phone`, `store_email`, `status`, `created_on`, `created_by`, `modified_on`, `modified_by`) VALUES
(1, 'Store A', 'STR001', 'Erode', '7777777777', 'storeainfo@gmail.com', 1, '2019-07-04 06:18:44', 1, '2019-10-19 16:27:14', 8),
(2, 'Store B', 'STR002', 'Covai', '8878787998', 'storebinfo@gmail.com', 1, '2019-07-05 04:15:29', 1, '2019-10-19 16:27:14', 8),
(3, 'Store C', 'STR003', 'Salem', '8884074278', 'storeccinfo@gmail.com', 1, '2019-07-11 22:53:02', 1, '2019-10-21 15:46:02', 8),
(4, 'Store D', 'STR004', 'Chennai', '8248182544', 'sureshmca@gmail.com', 1, '2019-10-15 07:05:39', 8, '2019-10-19 16:27:14', 8),
(5, 'Store E', 'STR005', 'Erode', '9999999999', 'storee@maharajacanteen.com', 1, '2019-10-19 06:59:40', 7, '2019-10-19 16:21:34', 1),
(6, 'Store F', 'STR006', 'Namakkal', '8888888888', 'storef@maharajacanteen.com', 1, '2019-10-19 07:06:16', 7, '2019-10-19 16:22:15', 1);
