
-- --------------------------------------------------------

--
-- Table structure for table `user_type`
--

CREATE TABLE `user_type` (
  `user_type_id` int(11) NOT NULL,
  `type` varchar(80) NOT NULL,
  `role` varchar(25) NOT NULL,
  `description` varchar(150) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_type`
--

INSERT INTO `user_type` (`user_type_id`, `type`, `role`, `description`, `status`) VALUES
(1, 'root_admin', 'developer', 'for developer', 1),
(2, 'super_admin', 'admin', 'for app administrator', 1),
(3, 'store', 'manager', 'for store managers', 1),
(4, 'stall', 'operator', 'for store operators', 1);
