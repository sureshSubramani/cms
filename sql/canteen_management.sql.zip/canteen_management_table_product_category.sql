
-- --------------------------------------------------------

--
-- Table structure for table `product_category`
--

CREATE TABLE `product_category` (
  `category_id` int(11) NOT NULL,
  `product_category` varchar(100) NOT NULL,
  `short_name` varchar(10) NOT NULL,
  `category_details` text,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) NOT NULL COMMENT 'Created user ID',
  `modified_on` datetime NOT NULL DEFAULT '0000-01-01 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `modified_by` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_category`
--

INSERT INTO `product_category` (`category_id`, `product_category`, `short_name`, `category_details`, `status`, `created_on`, `created_by`, `modified_on`, `modified_by`) VALUES
(1, 'Vegetable', 'VEG', ' 1111', 1, '2019-10-21 06:34:23', 1, '2019-10-25 10:55:32', 1),
(2, 'Fruits', 'FRUIT', NULL, 1, '2019-10-21 06:34:23', 1, '2019-10-22 16:56:10', NULL),
(3, 'Herbs', 'HERB', NULL, 1, '2019-10-21 06:34:23', 1, '2019-10-22 16:56:10', NULL),
(4, 'Lentils & Beans', 'LEBE', NULL, 1, '2019-10-21 06:34:23', 1, '2019-10-22 16:56:10', NULL),
(5, 'Flour', 'FLOUR', NULL, 1, '2019-10-21 06:34:23', 1, '2019-10-22 16:56:10', NULL),
(6, 'Rice & Grains', 'RCGR', NULL, 1, '2019-10-21 06:34:23', 1, '2019-10-22 16:56:10', NULL),
(7, 'Nuts, Seeds, Dried fruits', 'NSDF', NULL, 1, '2019-10-21 06:34:23', 1, '2019-10-22 16:56:10', NULL),
(8, 'Dairy', 'DAIRY', NULL, 1, '2019-10-21 06:34:23', 1, '2019-10-22 16:56:10', NULL),
(9, 'Baking items', 'BAK', NULL, 1, '2019-10-21 06:34:23', 1, '2019-10-22 16:56:10', NULL),
(10, 'Odds & Ends', 'ODEN', NULL, 1, '2019-10-21 06:34:23', 1, '2019-10-23 12:29:59', NULL),
(11, 'Drinks', 'DRINK', NULL, 1, '2019-10-22 01:49:49', 1, '2019-10-22 16:56:10', NULL),
(12, 'Fats and Oils', 'FAOIL', NULL, 1, '2019-10-22 02:04:04', 1, '2019-10-22 16:56:10', NULL),
(13, 'Spices', 'SPICE', NULL, 1, '2019-10-22 03:16:40', 1, '2019-10-22 16:56:10', NULL),
(14, 'Fluid and Drinks', 'FLDR', NULL, 1, '2019-09-23 03:11:37', 1, '0000-01-01 00:00:00', NULL),
(15, 'Snacks', 'SNACK', NULL, 1, '2019-09-23 03:11:37', 1, '2019-10-23 10:11:11', NULL),
(16, 'Medicine', 'MEDI', NULL, 0, '2019-09-23 03:11:37', 1, '0000-01-01 00:00:00', NULL),
(17, 'Health Care', 'HEALTH', NULL, 0, '2019-09-23 03:11:37', 1, '0000-01-01 00:00:00', NULL),
(18, 'Personal Care', 'PERS', NULL, 0, '2019-09-23 03:11:37', 1, '0000-01-01 00:00:00', NULL),
(19, 'Home Cleaner', 'HOME', NULL, 0, '2019-09-23 03:11:37', 1, '0000-01-01 00:00:00', NULL),
(20, 'Bathroom Cleaner', 'BATH', NULL, 0, '2019-09-23 03:11:37', 1, '0000-01-01 00:00:00', NULL),
(21, 'Baby Care', 'BABY', NULL, 0, '2019-09-26 06:00:35', 1, '0000-01-01 00:00:00', NULL);
