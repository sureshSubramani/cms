
-- --------------------------------------------------------

--
-- Table structure for table `ticket_entry`
--

CREATE TABLE `ticket_entry` (
  `ticket_id` int(11) NOT NULL,
  `bill_id` varchar(255) NOT NULL,
  `print_date` date NOT NULL,
  `ticket_type` varchar(255) NOT NULL,
  `adult` int(11) NOT NULL,
  `child` int(11) NOT NULL,
  `adult_amnt` float NOT NULL,
  `child_amnt` float NOT NULL,
  `offer_amnt` float NOT NULL,
  `total_amnt` float NOT NULL,
  `payment_mode` varchar(255) NOT NULL,
  `offer_usr_name` varchar(255) NOT NULL,
  `offeer_position` varchar(255) NOT NULL,
  `remanded_by` varchar(255) NOT NULL,
  `modified_by` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ticket_entry`
--

INSERT INTO `ticket_entry` (`ticket_id`, `bill_id`, `print_date`, `ticket_type`, `adult`, `child`, `adult_amnt`, `child_amnt`, `offer_amnt`, `total_amnt`, `payment_mode`, `offer_usr_name`, `offeer_position`, `remanded_by`, `modified_by`, `created_on`, `status`) VALUES
(1, 'MAHTHEME0001', '2019-10-08', '5D', 1, 1, 570, 475, 55, 1045, 'card', '', '', '', '2019-10-08 06:05:37', '2019-10-08 06:05:37', 1),
(2, 'MAHTHEME0002', '2019-10-09', '5D', 10, 10, 570, 475, 55, 10450, 'cash', '', '', '', '2019-10-09 04:09:34', '2019-10-09 04:09:34', 1),
(3, 'MAHTHEME0003', '2019-10-19', '5D', 0, 0, 570, 475, 55, 0, 'cash', '', '', '', '2019-10-19 12:17:12', '2019-10-19 12:17:12', 1),
(4, 'MAHTHEME0004', '2019-11-01', 'M', 10, 2, 600, 500, 0, 7000, 'cash', '', '', '', '2019-11-01 07:07:51', '2019-11-01 07:07:51', 1);
