
-- --------------------------------------------------------

--
-- Table structure for table `menu_preference`
--

CREATE TABLE `menu_preference` (
  `preference_id` int(11) NOT NULL,
  `user_type` varchar(50) NOT NULL,
  `user_role` varchar(55) NOT NULL,
  `menu_preference` text,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL,
  `modified_on` datetime NOT NULL DEFAULT '0000-01-01 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `modified_by` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menu_preference`
--

INSERT INTO `menu_preference` (`preference_id`, `user_type`, `user_role`, `menu_preference`, `status`, `created_on`, `created_by`, `modified_on`, `modified_by`) VALUES
(1, 'root_admin', 'developer', NULL, 1, '2019-07-13 07:37:00', 1, '0000-01-01 00:00:00', NULL),
(2, 'super_admin', 'admin', '{"1":"index","8":"store_details","22":"stall_details","23":"supplier_details","7":{"40":"product_details","39":"product_category","41":"sales_products","51":"stall_products"},"24":{"35":"purchase","27":"invoice_payment","50":"payment_by_supplier","37":"movement_tracker","43":"wastage","36":"stock_of_store","38":"stock_of_stall"},"28":{"30":"sales","29":"stock_of_sales"},"31":{"32":"purchase_reports","33":"payment_reports","34":"sales_reports"},"6":{"10":"user_details","12":"user_role"},"9":{"11":"menu_details","26":"menu_preference"}}', 1, '2019-07-13 09:12:23', 1, '2019-10-17 12:28:34', NULL),
(3, 'store', 'manager', '{"1":"index","8":"store_details","22":"stall_details","23":"supplier_details","7":{"51":"stall_products"},"24":{"35":"purchase","27":"invoice_payment","50":"payment_by_supplier","37":"movement_tracker","43":"wastage","36":"stock_of_store","38":"stock_of_stall"},"28":{"30":"sales","29":"stock_of_sales"},"31":{"32":"purchase_reports","33":"payment_reports","34":"sales_reports"}}', 1, '2019-07-15 04:37:36', 1, '2019-10-22 16:51:03', NULL),
(4, 'stall', 'operator', '{"1":"index","24":{"43":"wastage","38":"stock_of_stall"},"28":{"30":"sales","29":"stock_sales"},"52":"locker","53":"ticket_entry"}', 1, '2019-07-15 04:37:40', 1, '2019-11-01 10:46:02', NULL),
(7, 'super_admin', 'MD', '{"1":"index"}', 1, '2019-09-18 11:57:03', 1, '0000-01-01 00:00:00', NULL);
